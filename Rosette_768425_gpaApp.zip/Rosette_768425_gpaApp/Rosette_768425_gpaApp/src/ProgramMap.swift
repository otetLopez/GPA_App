//
//  ProgramMap.swift
//  Rosette_768425_gpaApp
//
//  Created by otet_tud on 11/14/19.
//  Copyright © 2019 otet_tud. All rights reserved.
//

import Foundation


let programmap : [[String]] = [["MAD 3004", "MAD 2303", "MAD 3463", "MAD 3115", "MAD 3125"], // First Term
                               ["MAD 3114", "MAD 4114", "MAD 4124", "MAD 5254", "MAD 5264"], // Second Term
                               ["MAD 5234", "MAD 5274", "MAD 6114", "MAD 6123", "MAD 6135"]] // Third Term

